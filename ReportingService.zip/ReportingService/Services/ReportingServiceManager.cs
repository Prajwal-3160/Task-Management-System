using System.Net.Http.Json;
using ReportingService.DTOs;

namespace ReportingService.Services;

public class ReportingServiceManager : IReportingService
{
    private readonly HttpClient _httpClient;

    public ReportingServiceManager(HttpClient httpClient)
    {
        _httpClient = httpClient;
    }

    public async Task<List<TaskByUserDto>> GetTasksByUserAsync(CancellationToken cancellationToken)
    {
        var tasks = await GetTasksAsync(cancellationToken);
        return tasks
            .GroupBy(task => task.AssigneeId)
            .Select(group => new TaskByUserDto
            {
                AssigneeId = group.Key,
                TaskCount = group.Count()
            })
            .OrderBy(report => report.AssigneeId)
            .ToList();
    }

    public async Task<List<TaskByStatusDto>> GetTasksByStatusAsync(CancellationToken cancellationToken)
    {
        var tasks = await GetTasksAsync(cancellationToken);
        return tasks
            .GroupBy(task => task.Status)
            .Select(group => new TaskByStatusDto
            {
                Status = group.Key,
                Count = group.Count()
            })
            .OrderBy(report => report.Status)
            .ToList();
    }

    public async Task<List<SlaReportDto>> GetSlaReportAsync(CancellationToken cancellationToken)
    {
        var tasks = await GetTasksAsync(cancellationToken);
        var today = DateTime.UtcNow.Date;

        return tasks
            .Where(task => task.DueDate.Date < today &&
                           !string.Equals(task.Status, "Completed", StringComparison.OrdinalIgnoreCase))
            .Select(task => new SlaReportDto
            {
                TaskId = task.Id,
                Title = task.Title,
                Owner = $"User #{task.AssigneeId}",
                DaysOverdue = Math.Max(1, (int)Math.Ceiling((today - task.DueDate.Date).TotalDays))
            })
            .OrderByDescending(report => report.DaysOverdue)
            .ToList();
    }

    private async Task<List<TaskServiceTask>> GetTasksAsync(CancellationToken cancellationToken)
    {
        return await _httpClient.GetFromJsonAsync<List<TaskServiceTask>>(
                   "api/Task",
                   cancellationToken)
               ?? throw new InvalidOperationException("Task Service returned an empty response.");
    }

    private sealed class TaskServiceTask
    {
        public int Id { get; set; }
        public string Title { get; set; } = string.Empty;
        public string Status { get; set; } = string.Empty;
        public int AssigneeId { get; set; }
        public DateTime DueDate { get; set; }
    }
}
