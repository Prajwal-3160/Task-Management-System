using ReportingService.DTOs;

namespace ReportingService.Services;

public interface IReportingService
{
    Task<List<TaskByUserDto>> GetTasksByUserAsync(CancellationToken cancellationToken);

    Task<List<TaskByStatusDto>> GetTasksByStatusAsync(CancellationToken cancellationToken);

    Task<List<SlaReportDto>> GetSlaReportAsync(CancellationToken cancellationToken);
}