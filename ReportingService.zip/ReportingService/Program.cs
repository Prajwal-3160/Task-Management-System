using ReportingService.Middleware;
using ReportingService.Services;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var taskServiceBaseUrl = builder.Configuration["TaskService:BaseUrl"]
    ?? throw new InvalidOperationException("TaskService:BaseUrl is not configured.");
builder.Services.AddHttpClient<IReportingService, ReportingServiceManager>(client =>
{
    client.BaseAddress = new Uri(taskServiceBaseUrl);
});

builder.Services.AddCors(options =>
{
    options.AddPolicy("LocalUi", policy =>
        policy.WithOrigins("http://localhost:4200")
            .AllowAnyHeader()
            .AllowAnyMethod());
});

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseCors("LocalUi");
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseMiddleware<ExceptionMiddleware>();

app.UseHttpsRedirection();

app.MapControllers();

app.Run();

public partial class Program
{
}