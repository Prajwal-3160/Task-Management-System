namespace ReportingService.DTOs;

public class TaskByUserDto
{
    public int AssigneeId { get; set; }

    public int TaskCount { get; set; }
}