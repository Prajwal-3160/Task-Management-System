namespace ReportingService.DTOs;

public class SlaReportDto
{
    public int TaskId { get; set; }

    public string Title { get; set; } = string.Empty;

    public string Owner { get; set; } = string.Empty;

    public int DaysOverdue { get; set; }
}