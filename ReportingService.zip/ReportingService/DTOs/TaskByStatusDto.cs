namespace ReportingService.DTOs;

public class TaskByStatusDto
{
    public string Status { get; set; } = string.Empty;

    public int Count { get; set; }
}