using Microsoft.AspNetCore.Mvc;
using ReportingService.Services;

namespace ReportingService.Controllers;

[ApiController]
[Route("api/[controller]")]
public class ReportController : ControllerBase
{
    private readonly IReportingService _service;

    public ReportController(IReportingService service)
    {
        _service = service;
    }

    [HttpGet("tasksbyuser")]
    public async Task<IActionResult> GetTasksByUser(CancellationToken cancellationToken)
    {
        return Ok(await _service.GetTasksByUserAsync(cancellationToken));
    }

    [HttpGet("tasksbystatus")]
    public async Task<IActionResult> GetTasksByStatus(CancellationToken cancellationToken)
    {
        return Ok(await _service.GetTasksByStatusAsync(cancellationToken));
    }

    [HttpGet("slareport")]
    public async Task<IActionResult> GetSlaReport(CancellationToken cancellationToken)
    {
        return Ok(await _service.GetSlaReportAsync(cancellationToken));
    }
}