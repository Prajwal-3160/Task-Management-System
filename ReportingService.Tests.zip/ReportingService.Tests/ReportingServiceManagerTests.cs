using System.Net;
using System.Text;
using ReportingService.Services;

namespace ReportingService.Tests;

public class ReportingServiceManagerTests
{
    [Fact]
    public async Task GetTasksByUser_GroupsTasksByAssignee()
    {
        using var client = CreateClient();
        var service = new ReportingServiceManager(client);

        var result = await service.GetTasksByUserAsync(CancellationToken.None);

        Assert.Collection(
            result,
            item =>
            {
                Assert.Equal(2, item.AssigneeId);
                Assert.Equal(3, item.TaskCount);
            },
            item =>
            {
                Assert.Equal(5, item.AssigneeId);
                Assert.Equal(1, item.TaskCount);
            });
    }

    [Fact]
    public async Task GetTasksByStatus_GroupsAndOrdersStatuses()
    {
        using var client = CreateClient();
        var service = new ReportingServiceManager(client);

        var result = await service.GetTasksByStatusAsync(CancellationToken.None);

        Assert.Collection(
            result,
            item => Assert.Equal(("Blocked", 1), (item.Status, item.Count)),
            item => Assert.Equal(("Completed", 1), (item.Status, item.Count)),
            item => Assert.Equal(("Open", 2), (item.Status, item.Count)));
    }

    [Fact]
    public async Task GetSlaReport_OnlyIncludesOverdueIncompleteTasks()
    {
        using var client = CreateClient();
        var service = new ReportingServiceManager(client);

        var result = await service.GetSlaReportAsync(CancellationToken.None);

        var report = Assert.Single(result);
        Assert.Equal(10, report.TaskId);
        Assert.Equal("Overdue", report.Title);
        Assert.Equal("User #2", report.Owner);
        Assert.True(report.DaysOverdue >= 1);
    }

    [Fact]
    public async Task GetTasksByStatus_PropagatesTaskServiceFailure()
    {
        using var client = CreateClient(HttpStatusCode.ServiceUnavailable);
        var service = new ReportingServiceManager(client);

        await Assert.ThrowsAsync<HttpRequestException>(
            () => service.GetTasksByStatusAsync(CancellationToken.None));
    }

    private static HttpClient CreateClient(HttpStatusCode statusCode = HttpStatusCode.OK)
    {
        const string response = """
            [
              { "id": 10, "title": "Overdue", "status": "Open", "assigneeId": 2, "dueDate": "2020-01-01T00:00:00Z" },
              { "id": 11, "title": "Completed overdue", "status": "Completed", "assigneeId": 2, "dueDate": "2020-01-01T00:00:00Z" },
              { "id": 12, "title": "Due today", "status": "Open", "assigneeId": 5, "dueDate": "2099-01-01T00:00:00Z" },
              { "id": 13, "title": "Blocked", "status": "Blocked", "assigneeId": 2, "dueDate": "2099-01-01T00:00:00Z" }
            ]
            """;

        return new HttpClient(new StubHttpMessageHandler(
            statusCode,
            statusCode == HttpStatusCode.OK ? response : string.Empty))
        {
            BaseAddress = new Uri("http://task-service/")
        };
    }

    private sealed class StubHttpMessageHandler(
        HttpStatusCode statusCode,
        string responseBody) : HttpMessageHandler
    {
        protected override Task<HttpResponseMessage> SendAsync(
            HttpRequestMessage request,
            CancellationToken cancellationToken)
        {
            Assert.Equal("/api/Task", request.RequestUri?.AbsolutePath);
            return Task.FromResult(new HttpResponseMessage(statusCode)
            {
                Content = new StringContent(responseBody, Encoding.UTF8, "application/json")
            });
        }
    }
}
