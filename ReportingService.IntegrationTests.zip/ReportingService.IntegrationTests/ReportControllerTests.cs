using System.Net;
using System.Net.Http.Json;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.AspNetCore.TestHost;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using ReportingService.DTOs;
using ReportingService.Services;

namespace ReportingService.IntegrationTests;

public class ReportControllerTests : IClassFixture<ReportingServiceFactory>
{
    private readonly HttpClient _client;

    public ReportControllerTests(ReportingServiceFactory factory)
    {
        _client = factory.CreateClient();
    }

    [Fact]
    public async Task GetTasksByStatus_ReturnsReportData()
    {
        var response = await _client.GetAsync("/api/report/tasksbystatus");

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        var result = await response.Content.ReadFromJsonAsync<List<TaskByStatusDto>>();
        var report = Assert.Single(result!);
        Assert.Equal("Open", report.Status);
        Assert.Equal(3, report.Count);
    }

    [Fact]
    public async Task GetSlaReport_ReturnsOverdueItems()
    {
        var response = await _client.GetAsync("/api/report/slareport");

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        var result = await response.Content.ReadFromJsonAsync<List<SlaReportDto>>();
        var report = Assert.Single(result!);
        Assert.Equal(9, report.TaskId);
    }
}

public sealed class ReportingServiceFactory : WebApplicationFactory<Program>
{
    protected override void ConfigureWebHost(IWebHostBuilder builder)
    {
        builder.UseContentRoot(AppContext.BaseDirectory);
        builder.UseSetting("TaskService:BaseUrl", "http://localhost/");
        builder.ConfigureTestServices(services =>
        {
            services.RemoveAll<IReportingService>();
            services.AddSingleton<IReportingService>(new FakeReportingService());
        });
    }

    private sealed class FakeReportingService : IReportingService
    {
        public Task<List<TaskByUserDto>> GetTasksByUserAsync(CancellationToken cancellationToken) =>
            Task.FromResult(new List<TaskByUserDto>
            {
                new() { AssigneeId = 2, TaskCount = 3 }
            });

        public Task<List<TaskByStatusDto>> GetTasksByStatusAsync(CancellationToken cancellationToken) =>
            Task.FromResult(new List<TaskByStatusDto>
            {
                new() { Status = "Open", Count = 3 }
            });

        public Task<List<SlaReportDto>> GetSlaReportAsync(CancellationToken cancellationToken) =>
            Task.FromResult(new List<SlaReportDto>
            {
                new() { TaskId = 9, Title = "Late task", Owner = "User #2", DaysOverdue = 2 }
            });
    }
}
